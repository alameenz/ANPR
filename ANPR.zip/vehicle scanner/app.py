from flask import Flask, render_template, url_for, request, session
from flask import *
import sqlite3
import secrets
import threading
import time
import telepot
from datetime import date
import pandas as pd
import cv2
connection = sqlite3.connect('user_data.db')
cursor = connection.cursor()

command = """CREATE TABLE IF NOT EXISTS user(name TEXT, password TEXT, mobile TEXT, email TEXT)"""
cursor.execute(command)

cursor.execute("""create table if not exists BikeDetails (
    numberplate TEXT, model TEXT, year TEXT, color TEXT, engine_size TEXT, fuel_type TEXT, 
    transmission_type  TEXT, mileage  TEXT, price TEXT, condition_type TEXT, 
    additional_features TEXT, owner_details TEXT, 
    registration_details TEXT, insurance_details TEXT, emission_details TEXT)""")

def send_alerts():
    connection = sqlite3.connect('user_data.db')
    cursor = connection.cursor()
    while True:
        today = date.today()
        today = pd.to_datetime(today)
        cursor.execute("select * from BikeDetails")
        result = cursor.fetchall()
        for row in result:
            end = pd.to_datetime(row[-2])
            if (today - end).days == 1:
                msg="insurence date expired".format(row[1])
                print(msg)
                bot = telepot.Bot("7050343714:AAEDdgLMOquR06RvP8VFDgrXPuu_qcwjCu8")
                bot.sendMessage("1388858613", str(msg))
            
            end = pd.to_datetime(row[-1])
            if (today - end).days == 1:
                msg="emission test date expired".format(row[1])
                print(msg)
                bot = telepot.Bot("7050343714:AAEDdgLMOquR06RvP8VFDgrXPuu_qcwjCu8")
                bot.sendMessage("1388858613", str(msg))
        time.sleep(60)

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/Uhome')
def Uhome():
    return render_template('userlog.html')

@app.route('/userlog', methods=['GET', 'POST'])
def userlog():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']

        query = "SELECT * FROM user WHERE name = '"+name+"' AND password= '"+password+"'"
        cursor.execute(query)

        result = cursor.fetchone()

        if result:
            session['user'] = result[0]
            return render_template('add.html')
        else:
            return render_template('index.html', msg='Sorry, Incorrect Credentials Provided,  Try Again')

    return render_template('index.html')


@app.route('/userreg', methods=['GET', 'POST'])
def userreg():
    if request.method == 'POST':

        connection = sqlite3.connect('user_data.db')
        cursor = connection.cursor()

        name = request.form['name']
        password = request.form['password']
        mobile = request.form['phone']
        email = request.form['email']
        
        print(name, mobile, email, password)

        cursor.execute("INSERT INTO user VALUES ('"+name+"', '"+password+"', '"+mobile+"', '"+email+"')")
        connection.commit()

        return render_template('index.html', msg='Successfully Registered')
    
    return render_template('index.html')

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        numberplate = request.form['numberplate']
        model = request.form['model']
        year = request.form['year']
        color = request.form['color']
        engine_size = request.form['engine']
        fuel_type = request.form['fuel']
        transmission_type = request.form['transmission']
        mileage = request.form['mileage']
        price = request.form['price']
        condition = request.form['condition']
        features = request.form['features']
        owner = request.form['owner']
        registration = request.form['registration']
        insurance = request.form['insurance']
        emission = request.form['emission']

        conn = sqlite3.connect('user_data.db')
        c = conn.cursor()

        c.execute('''INSERT INTO BikeDetails 
                     (numberplate, model, year, color, engine_size, fuel_type, transmission_type, 
                     mileage, price, condition_type, additional_features, owner_details, 
                     registration_details, insurance_details, emission_details) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                  [numberplate, model, year, color, engine_size, fuel_type, transmission_type,
                   mileage, price, condition, features, owner, registration, insurance, emission])
        conn.commit()
        conn.close()

        return render_template('add.html', msg = "Successfully added")
    return render_template('add.html')

@app.route('/get')
def get():
    conn = sqlite3.connect('user_data.db')
    c = conn.cursor()

    vs = cv2.VideoCapture(0)
    while True:
        ret, img = vs.read()
        cv2.imshow("numberplate", img)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            cv2.imwrite('frame.png', img)
            break

    vs.release()
    cv2.destroyAllWindows()
    try:
        import requests
        from pprint import pprint
        ##regions = ["mx", "us-ca"] # Change to your country
        with open('frame.png', 'rb') as fp:
            response = requests.post(
                'https://api.platerecognizer.com/v1/plate-reader/',
                files=dict(upload=fp),
                headers={'Authorization': 'Token 81dda232b51e3f7c7620f0830834a6d8c94e0120'})
        results = response.json()
        d = results['results'][0]['plate'].upper()
        print(d)

        c.execute("select * from BikeDetails where numberplate = '"+d+"'")
        result = c.fetchone()
        return render_template('get.html', result = result)
    except:
        return render_template('get.html', msg = 'numberplate not recognised')

@app.route('/getpage')
def getpage():
    return render_template('get.html')

@app.route('/logout')
def logout():
    return render_template('index.html')

if __name__ == "__main__":
    thread = threading.Thread(target=send_alerts)
    thread.start()
    app.run(debug=True, use_reloader=False)
